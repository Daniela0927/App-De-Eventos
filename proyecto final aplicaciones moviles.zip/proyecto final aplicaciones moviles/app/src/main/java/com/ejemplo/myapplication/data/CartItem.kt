package com.ejemplo.myapplication.data

data class CartItem(
    val event: Event,
    val quantity: Int
) {
    val totalPrice: Double
        get() = event.price * quantity
}

