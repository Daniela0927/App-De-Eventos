package com.ejemplo.myapplication.data

data class Event(
    val id: String,
    val name: String,
    val description: String,
    val date: String,
    val time: String,
    val location: String,
    val price: Double,
    val category: EventCategory,
    val imageUrl: String = "",
    val availableTickets: Int = 100
)

enum class EventCategory(val displayName: String) {
    CONCIERTOS("Conciertos"),
    DEPORTIVOS("Deportivos"),
    CONFERENCIAS("Conferencias"),
    FESTIVALES("Festivales"),
    TALLERES("Talleres"),
    CINE("Cine"),
    PROMOCIONES("Promociones Especiales")
}

