package com.ejemplo.myapplication.data

object EventRepository {
    private val events = listOf(
        Event(
            id = "1",
            name = "Concierto de Rock Nacional",
            description = "Disfruta de una noche inolvidable con las mejores bandas de rock nacional. Incluye artistas destacados y un ambiente único.",
            date = "15 de Marzo, 2024",
            time = "20:00",
            location = "Estadio Nacional",
            price = 45.00,
            category = EventCategory.CONCIERTOS,
            availableTickets = 50
        ),
        Event(
            id = "2",
            name = "Partido de Fútbol: Liga Local",
            description = "No te pierdas el partido más esperado de la temporada. Dos equipos históricos se enfrentan en un duelo épico.",
            date = "20 de Marzo, 2024",
            time = "18:00",
            location = "Estadio Municipal",
            price = 30.00,
            category = EventCategory.DEPORTIVOS,
            availableTickets = 200
        ),
        Event(
            id = "3",
            name = "Conferencia de Tecnología 2024",
            description = "Únete a los líderes de la industria tecnológica para discutir las últimas tendencias y avances en el sector.",
            date = "25 de Marzo, 2024",
            time = "10:00",
            location = "Centro de Convenciones",
            price = 75.00,
            category = EventCategory.CONFERENCIAS,
            availableTickets = 150
        ),
        Event(
            id = "4",
            name = "Festival de Música Electrónica",
            description = "El festival más grande del año con los mejores DJs internacionales. Una experiencia única de música y luces.",
            date = "5 de Abril, 2024",
            time = "22:00",
            location = "Parque Central",
            price = 60.00,
            category = EventCategory.FESTIVALES,
            availableTickets = 300
        ),
        Event(
            id = "5",
            name = "Taller de Fotografía Digital",
            description = "Aprende las técnicas más avanzadas de fotografía digital con profesionales reconocidos. Incluye materiales.",
            date = "12 de Abril, 2024",
            time = "14:00",
            location = "Academia de Arte",
            price = 50.00,
            category = EventCategory.TALLERES,
            availableTickets = 25
        ),
        Event(
            id = "6",
            name = "Estreno: Película Independiente",
            description = "Estreno exclusivo de la película más esperada del año. Incluye sesión de preguntas con el director.",
            date = "18 de Abril, 2024",
            time = "19:30",
            location = "Cine Premium",
            price = 12.00,
            category = EventCategory.CINE,
            availableTickets = 80
        ),
        Event(
            id = "7",
            name = "Oferta Especial: Paquete Familiar",
            description = "Promoción especial para toda la familia. Incluye acceso a múltiples eventos con descuento exclusivo.",
            date = "1 de Mayo, 2024",
            time = "Todo el día",
            location = "Varios lugares",
            price = 100.00,
            category = EventCategory.PROMOCIONES,
            availableTickets = 50
        )
    )

    fun getAllEvents(): List<Event> = events

    fun getEventsByCategory(category: EventCategory): List<Event> {
        return events.filter { it.category == category }
    }

    fun getEventById(id: String): Event? {
        return events.find { it.id == id }
    }

    fun getFeaturedEvents(): List<Event> {
        return events.take(3)
    }
}

