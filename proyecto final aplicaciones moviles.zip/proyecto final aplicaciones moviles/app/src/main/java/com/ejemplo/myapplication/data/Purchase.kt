package com.ejemplo.myapplication.data

data class Purchase(
    val id: String,
    val event: Event,
    val quantity: Int,
    val totalPrice: Double,
    val purchaseDate: String,
    val qrCode: String = "QR-${id}"
)

