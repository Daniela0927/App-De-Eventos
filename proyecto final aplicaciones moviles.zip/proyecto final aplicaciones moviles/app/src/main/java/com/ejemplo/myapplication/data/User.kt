package com.ejemplo.myapplication.data

data class User(
    val email: String,
    val name: String,
    val photoUrl: String? = null
)

