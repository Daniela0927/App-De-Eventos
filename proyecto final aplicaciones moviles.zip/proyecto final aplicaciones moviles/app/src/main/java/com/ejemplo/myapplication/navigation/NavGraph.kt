package com.ejemplo.myapplication.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.ejemplo.myapplication.data.EventCategory
import com.ejemplo.myapplication.screens.*
import com.ejemplo.myapplication.viewmodel.AppViewModel

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object Register : Screen("register")
    object ForgotPassword : Screen("forgot_password")
    object Home : Screen("home")
    object Categories : Screen("categories")
    object EventList : Screen("event_list/{category}") {
        fun createRoute(category: String) = "event_list/$category"
    }
    object EventDetail : Screen("event_detail/{eventId}") {
        fun createRoute(eventId: String) = "event_detail/$eventId"
    }
    object Cart : Screen("cart")
    object MyEvents : Screen("my_events")
    object Profile : Screen("profile")
}

@Composable
fun NavGraph(
    navController: NavHostController,
    viewModel: AppViewModel = viewModel()
) {
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val cart by viewModel.cart.collectAsState()
    val purchases by viewModel.purchases.collectAsState()

    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route
    ) {
        composable(Screen.Splash.route) {
            SplashScreen(
                onNavigateToLogin = {
                    if (isLoggedIn) {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Splash.route) { inclusive = true }
                        }
                    } else {
                        navController.navigate(Screen.Login.route) {
                            popUpTo(Screen.Splash.route) { inclusive = true }
                        }
                    }
                }
            )
        }

        composable(Screen.Login.route) {
            LoginScreen(
                onLogin = { email, password ->
                    if (viewModel.login(email, password)) {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Login.route) { inclusive = true }
                        }
                    }
                },
                onNavigateToRegister = {
                    navController.navigate(Screen.Register.route)
                },
                onNavigateToForgotPassword = {
                    navController.navigate(Screen.ForgotPassword.route)
                }
            )
        }

        composable(Screen.Register.route) {
            RegisterScreen(
                onRegister = { email, password, name ->
                    if (viewModel.register(email, password, name)) {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Register.route) { inclusive = true }
                        }
                    }
                },
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(Screen.ForgotPassword.route) {
            ForgotPasswordScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(Screen.Home.route) {
            HomeScreen(
                onNavigateToCategories = {
                    navController.navigate(Screen.Categories.route)
                },
                onNavigateToEventList = { categoryName ->
                    val category = EventCategory.values().find { it.displayName == categoryName }
                    if (category != null) {
                        navController.navigate(Screen.EventList.createRoute(category.name))
                    }
                },
                onNavigateToEventDetail = { eventId ->
                    navController.navigate(Screen.EventDetail.createRoute(eventId))
                },
                onNavigateToCart = {
                    navController.navigate(Screen.Cart.route)
                },
                onNavigateToMyEvents = {
                    navController.navigate(Screen.MyEvents.route)
                },
                onNavigateToProfile = {
                    navController.navigate(Screen.Profile.route)
                }
            )
        }

        composable(Screen.Categories.route) {
            CategoriesScreen(
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToEventList = { category ->
                    navController.navigate(Screen.EventList.createRoute(category.name))
                }
            )
        }

        composable(
            route = Screen.EventList.route,
            arguments = listOf(navArgument("category") { type = NavType.StringType })
        ) { backStackEntry ->
            val categoryName = backStackEntry.arguments?.getString("category") ?: ""
            val category = try {
                EventCategory.valueOf(categoryName)
            } catch (e: IllegalArgumentException) {
                EventCategory.CONCIERTOS
            }

            EventListScreen(
                category = category,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToEventDetail = { eventId ->
                    navController.navigate(Screen.EventDetail.createRoute(eventId))
                }
            )
        }

        composable(
            route = Screen.EventDetail.route,
            arguments = listOf(navArgument("eventId") { type = NavType.StringType })
        ) { backStackEntry ->
            val eventId = backStackEntry.arguments?.getString("eventId") ?: ""
            EventDetailScreen(
                eventId = eventId,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onAddToCart = { event, quantity ->
                    viewModel.addToCart(event, quantity)
                    navController.navigate(Screen.Cart.route)
                }
            )
        }

        composable(Screen.Cart.route) {
            CartScreen(
                cartItems = cart,
                total = viewModel.getCartTotal(),
                onNavigateBack = {
                    navController.popBackStack()
                },
                onRemoveItem = { eventId ->
                    viewModel.removeFromCart(eventId)
                },
                onUpdateQuantity = { eventId, quantity ->
                    viewModel.updateCartQuantity(eventId, quantity)
                },
                onCheckout = {
                    viewModel.checkout()
                    navController.navigate(Screen.MyEvents.route) {
                        popUpTo(Screen.Cart.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.MyEvents.route) {
            MyEventsScreen(
                purchases = purchases,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onShowQR = { qrCode ->
                    // QR code is shown in the dialog within MyEventsScreen
                }
            )
        }

        composable(Screen.Profile.route) {
            ProfileScreen(
                user = currentUser,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onLogout = {
                    viewModel.logout()
                    navController.navigate(Screen.Login.route) {
                        popUpTo(Screen.Profile.route) { inclusive = true }
                    }
                }
            )
        }
    }
}

