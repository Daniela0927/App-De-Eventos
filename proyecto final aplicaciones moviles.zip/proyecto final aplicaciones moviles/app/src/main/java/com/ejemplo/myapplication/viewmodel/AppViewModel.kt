package com.ejemplo.myapplication.viewmodel

import androidx.lifecycle.ViewModel
import com.ejemplo.myapplication.data.CartItem
import com.ejemplo.myapplication.data.Event
import com.ejemplo.myapplication.data.Purchase
import com.ejemplo.myapplication.data.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class AppViewModel : ViewModel() {
    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    private val _purchases = MutableStateFlow<List<Purchase>>(emptyList())
    val purchases: StateFlow<List<Purchase>> = _purchases.asStateFlow()

    fun login(email: String, password: String): Boolean {
        // Simulación de login - en producción usarías autenticación real
        if (email.isNotEmpty() && password.isNotEmpty()) {
            _currentUser.value = User(
                email = email,
                name = email.substringBefore("@")
            )
            _isLoggedIn.value = true
            return true
        }
        return false
    }

    fun register(email: String, password: String, name: String): Boolean {
        // Simulación de registro
        if (email.isNotEmpty() && password.isNotEmpty() && name.isNotEmpty()) {
            _currentUser.value = User(
                email = email,
                name = name
            )
            _isLoggedIn.value = true
            return true
        }
        return false
    }

    fun logout() {
        _isLoggedIn.value = false
        _currentUser.value = null
        _cart.value = emptyList()
    }

    fun addToCart(event: Event, quantity: Int = 1) {
        val currentCart = _cart.value.toMutableList()
        val existingItem = currentCart.find { it.event.id == event.id }
        
        if (existingItem != null) {
            val index = currentCart.indexOf(existingItem)
            currentCart[index] = existingItem.copy(quantity = existingItem.quantity + quantity)
        } else {
            currentCart.add(CartItem(event, quantity))
        }
        _cart.value = currentCart
    }

    fun removeFromCart(eventId: String) {
        _cart.value = _cart.value.filter { it.event.id != eventId }
    }

    fun updateCartQuantity(eventId: String, quantity: Int) {
        if (quantity <= 0) {
            removeFromCart(eventId)
            return
        }
        _cart.value = _cart.value.map {
            if (it.event.id == eventId) {
                it.copy(quantity = quantity)
            } else {
                it
            }
        }
    }

    fun getCartTotal(): Double {
        return _cart.value.sumOf { it.totalPrice }
    }

    fun checkout() {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val newPurchases = _cart.value.map { cartItem ->
            Purchase(
                id = UUID.randomUUID().toString(),
                event = cartItem.event,
                quantity = cartItem.quantity,
                totalPrice = cartItem.totalPrice,
                purchaseDate = dateFormat.format(Date())
            )
        }
        _purchases.value = _purchases.value + newPurchases
        _cart.value = emptyList()
    }
}

